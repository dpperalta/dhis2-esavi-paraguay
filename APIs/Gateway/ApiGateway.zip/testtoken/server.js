import express from "express";
import axios from "axios";
//import "dotenv/config"; // loads env variables from .env file

//const { CLIENT_ID, APP_SECRET } = process.env;
const { CLIENT_ID, APP_SECRET,SCOPE,USERNAME } = {CLIENT_ID:"mspclient",USERNAME:"24360",APP_SECRET:"26zKRTc63Q86E8GF95ZU", SCOPE:"meddraapi"};

const base = "https://mid.meddra.org";

const app = express();

// test route
app.get("/test", async (req, res) => {
  const data = await generateAccessToken();
  console.log(data)
  res.json(data);
});

async function generateAccessToken(){

    var options = {
    method: 'POST',
    url: base + "/connect/token",
    headers: {'content-type': 'application/x-www-form-urlencoded'},
    data: new URLSearchParams({
        grant_type: 'password',
        client_id: CLIENT_ID,
        username:USERNAME,
        password:APP_SECRET,
        scope: SCOPE,
    })
    };
    const resp = await axios(options);
    return resp.data;
}


app.listen(4000);