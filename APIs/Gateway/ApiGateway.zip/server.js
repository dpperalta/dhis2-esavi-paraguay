const express = require('express')

const SETTING= require("./src/config/setting.json")
const {getRoutes} = require("./src/gatewayApp/application/routes");
const {setupLogging} = require("./src/gatewayApp/infrastructure/repository/logging/logging");
const {setupRateLimit} = require("./src/gatewayApp/infrastructure/repository/limits/ratelimit");
const {setupProxies} = require("./src/gatewayApp/infrastructure/repository/proxy/proxy");
const {setupAuth} = require("./src/gatewayApp/infrastructure/repository/auth/auth");
const {setupCors} = require("./src/gatewayApp/infrastructure/repository/cors/cors");

const app = express()
app.use(express.json()) 
const port = 3000;
const ROUTES=getRoutes(SETTING);
//set logging in termial 
setupLogging(app);
setupRateLimit(app, ROUTES);
setupCors(app,ROUTES,SETTING)
setupAuth(app, ROUTES,SETTING);
setupProxies(app, ROUTES,SETTING);

app.listen(port, () => {
    console.log(`app listening at http://localhost:${port}`)
})
