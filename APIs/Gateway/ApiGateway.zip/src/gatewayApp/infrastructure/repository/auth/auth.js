const http = require('http');

const dhisAuth = (setting) => {
    return (req, res, next) => {
        const bearer_token=req.headers["authorization"]   
        if(bearer_token===undefined){
            console.log("Access Denegated")
            return res.sendStatus(401);
        }
        http.get(setting.dhis2.url + "/api/me", {headers: {'Authorization': bearer_token}} , (res_t) => {
            const { statusCode } = res_t
            if (statusCode !== 200) {
                console.log("Access Denegated")
                return res.sendStatus(401);
            }
        })
        next();
    }
}

const setupAuth = function (app, routes, setting) {
    routes.forEach(r => {
        if (r.auth) {
            app.use(dhisAuth(setting));
        }
    });
}

exports.setupAuth = setupAuth;