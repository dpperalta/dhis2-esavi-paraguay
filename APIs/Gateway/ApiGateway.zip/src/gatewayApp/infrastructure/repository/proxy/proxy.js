const axios = require('axios');

//Main method to setup middelware to handle redirect query to services.
const setupProxies = (app, routes,setting) => {
    routes.forEach(r => {
        let {target,method_and_services}=r.requestparams;
        app.post(r.url,RequestTarget(target,method_and_services,setting.meddra))
    })
}

exports.setupProxies = setupProxies

//Set handler acording to case selected, by now only there is one for meddra
const RequestTarget = (target,method_and_services,token_params) => {
    return async (req, res, next) => {
        switch (method_and_services){
            case "POST_MEDDRA":
                let _res= await handdleMeddra(target, token_params,req.body);             
                return res.send(_res.data);
        }  
        next();
    }
}

/////////////////////////////////////Handlers//////////////////////////////////////////////////

//handler to refress meddra token
const refreshMeddraToken=async ({url_token,client_id,username,app_secret,scope})=>{
    var options = {
        method: 'POST',
        url: url_token,
        headers: {'content-type': 'application/x-www-form-urlencoded'},
        data: new URLSearchParams({
            grant_type: 'password',
            client_id: client_id,
            username:username,
            password:app_secret,
            scope: scope,
        })
        };
        const resp = await axios(options);
        return resp.data;
}

//handler to meddra conection 
const handdleMeddra=async (target,token_params, data,retry=0)=>{
    if(retry==2)//retry 1 pattern implemented only one retry
        return {data:{error:"Error, please contact technical support"}}
    var options = {
        method: 'POST',
        url: target,
        headers: {'Authorization': "Bearer "+token_params.token},
        data
        };
    let resp={};
    try{
        resp = await axios(options);
    }
    catch(err){               
        switch(err.response.status){
        case 401://unautorized // retry one more time  when depend of expired token
            let newToken=await refreshMeddraToken(token_params);
            token_params.token=newToken.access_token
            resp=await handdleMeddra(target,token_params, data,retry+1); //retry 1 pattern implemented
            break;
        default:
            resp={data:{error:"Error, please contact technical support"}}
        }
    
    }
    return resp;
}
