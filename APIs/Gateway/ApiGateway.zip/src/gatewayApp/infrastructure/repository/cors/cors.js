const cors = require('cors');


const setupCors = function (app, routes, setting) {
      app.use(cors({
        origin: function(origin, callback){
          // allow requests with no origin 
          if(!origin) return callback(null, true);
          if(setting.allowedOrigins.indexOf(origin) === -1){
            var msg = 'The CORS policy for this site does not ' +
                      'allow access from the specified Origin.';
            return callback(new Error(msg), false);
          }
          return callback(null, true);
        }
      }));
}

exports.setupCors = setupCors;