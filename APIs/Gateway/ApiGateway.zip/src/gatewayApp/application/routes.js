const getRoutes =(setting)=> [
    {
        url: '/meddra',
        auth: false,
        requestparams:{
            target: setting.meddra.url,
            method_and_services:"POST_MEDDRA"
        }
    }
 
]

exports.getRoutes = getRoutes;
